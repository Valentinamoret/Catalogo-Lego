$(function(){

    $("#id_rut").inputmask({
        mask: "9[9.999.999]-[9|K|k]",
    });
  });

